# com.jorsek.intermediate

This DITA-OT plugin converts either a chapter or a full course to intermediate 
slide format. This format is used to generate further outputs. 

If you have set up your copy of the DITA-OT such that the `dita` command is on 
the path, you can install this plugin by simply typing

    ant install


Typing `ant` on its own will create the plugin zip file in the directory above the code itself. This can then be installed by typing

    ant -install com.jorsek.intermediate.zip

(with the path if required)

If you have previously installed it you will need to remove the previous version
first:

    ant -uninstall com.jorsek.intermediate.zip


## Prerequisites

* Install DITA-OT 2.5.4 or newer from [dita-ot.org](http://dita-ot.org/) .

* If installing from dita-ot.org then you will need to replace the Saxon jar files in the distribution with Saxon HE 9.6

* You _must_ install the `com.jorsek.doctypes` plugin first.


